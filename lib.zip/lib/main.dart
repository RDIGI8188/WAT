import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:wat/Bottombar.dart';
import 'package:wat/View/Auth/Login.dart';

import 'View/Auth/RegistrationPage.dart';
import 'View/Auth/splash.dart';
import 'View/Profile/AddPets.dart';
import 'View/Profile/Myfavourites.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
     debugShowCheckedModeBanner: false,
     home:Bottombar()
    );
  }
}
