import 'package:flutter/material.dart';

class ColorConstants {
  static const Color ButtonColor = Color(0xffFD5F4A);
  static const Color Button = Color(0xffED6D4E);
  static const Color TextColor = Color(0xffFFFFFF);
  static const Color SwitchButton = Color(0xff4552CB);
}
