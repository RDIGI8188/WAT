


import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../Controller/Profile/profilecontroller.dart';

class MyProfile extends StatelessWidget {
  final ProfileController controller = Get.put(ProfileController());

  void _showPicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: Icon(Icons.photo_library),
                title: Text('Gallery'),
                onTap: () {
                  controller.pickImage(ImageSource.gallery);
                  Navigator.of(context).pop();
                },
              ),
              ListTile(
                leading: Icon(Icons.photo_camera),
                title: Text('Camera'),
                onTap: () {
                  controller.pickImage(ImageSource.camera);
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final nameController = TextEditingController();
    final emailController = TextEditingController();
    final phoneController = TextEditingController();
    final cityController = TextEditingController();
    final pincodeController = TextEditingController();
    final addressController = TextEditingController();

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xffED6D4E), Color(0xffF1A852)],
                stops: [0.0, 1.0],
                begin: FractionalOffset.topLeft,
                end: FractionalOffset.bottomRight,
              ),
            ),
          ),
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios, size: 20),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Center(
            child: Text(
              'My Profile',
              style: GoogleFonts.encodeSans(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Colors.white,
              ),
            ),
          ),
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.all(16.0),
          child: Obx(() {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Stack(
                    children: [
                      Obx(() => CircleAvatar(
                            radius: 60,
                            backgroundImage: controller.image.value != null
                                ? FileImage(controller.image.value!)
                                : AssetImage("assets/Images/Profile.png") as ImageProvider,
                          )),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: GestureDetector(
                          onTap: () => _showPicker(context),
                          child: Container(
                            padding: EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: Color(0xffED6D4E),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(Icons.add, color: Colors.white, size: 22),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 24),
                _buildTextField('Full Name', nameController),
                SizedBox(height: 24),
                Text('Gender', style: _labelStyle()),
                SizedBox(height: 10),
                Obx(
                  () => Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildGenderButton(
                        'Male',
                        Icons.male,
                        controller.isMale.value,
                        () => controller.toggleGender(true),
                      ),
                      SizedBox(width: 20),
                      _buildGenderButton(
                        'Female',
                        Icons.female,
                        !controller.isMale.value,
                        () => controller.toggleGender(false),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 24),
                _buildTextField('Phone', phoneController, initialValue: controller.mobileNumber.value),
                SizedBox(height: 24),
                _buildTextField('Email', emailController),
                SizedBox(height: 24),
                _buildTextField('City', cityController),
                SizedBox(height: 24),
                _buildTextField('Pincode', pincodeController),
                SizedBox(height: 24),
                _buildTextField('Address', addressController, isMultiLine: true),
                SizedBox(height: 32),
                Text('User ID: ${controller.userId}', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    child: Text('Save', style: _buttonTextStyle()),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xffED6D4E),
                      padding: EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () {
                      controller.updateProfile(
                        name: nameController.text,
                        email: emailController.text,
                        mobileNumber: phoneController,
                        city: cityController.text,
                        pincode: pincodeController.text,
                        address: addressController.text,
                        profileImage: controller.image.value,
                      );
                    },
                  ),
                ),
                SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    child: Text('Logout', style: _buttonTextStyle()),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      padding: EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () {
                      controller.logout(); 
                    },
                  ),
                ),
              ],
            );
          }),
        ),
      ),
    );
  }

  TextStyle _labelStyle() {
    return GoogleFonts.encodeSans(
      fontWeight: FontWeight.bold,
      fontSize: 15,
      color: Color(0xffBBC3CE),
    );
  }

  TextStyle _buttonTextStyle() {
    return GoogleFonts.encodeSans(
      fontWeight: FontWeight.w700,
      fontSize: 16,
      color: Colors.white,
    );
  }

  Widget _buildTextField(String label, TextEditingController controller, {bool isMultiLine = false, String? initialValue}) {
    if (initialValue != null) {
      controller.text = initialValue; 
    }
    return TextField(
      controller: controller,
      maxLines: isMultiLine ? 2 : 1,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: _labelStyle(),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.grey),
        ),
      ),
    );
  }

  Widget _buildGenderButton(String label, IconData icon, bool isSelected, VoidCallback onTap) {
    return Expanded(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: isSelected ? Color(0xffED6D4E) : Colors.grey,
          padding: EdgeInsets.symmetric(vertical: 14),
        ),
        onPressed: onTap,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white),
            SizedBox(width: 8),
            Text(label, style: TextStyle(color: Colors.white)),
          ],
        ),
      ),
    );
  }
}
