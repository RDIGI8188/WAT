import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../utils/color_constant.dart';
import 'Help.dart';
import 'MyProfile.dart';
import 'Myfavourites.dart';
import 'Mypets.dart';
import 'Settings.dart';


class Profile extends StatelessWidget {
  const Profile({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              children: [
                Stack(
                  children: [
                    Card(
                      elevation: 5,
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        height: 260,
                        decoration: const BoxDecoration(
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(top: 10, left: 150),
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    "Profile",
                                    style: GoogleFonts.encodeSans(
                                        textStyle: const TextStyle(
                                            fontWeight: FontWeight.w900,
                                            fontSize: 18)),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 80),
                            ],
                          ),
                          const SizedBox(height: 20),
                          const CircleAvatar(
                            radius: 50,
                            backgroundImage: AssetImage("assets/Images/Profile.png"),
                          ),
                          const SizedBox(height: 20),
                          Text(
                            "Maria Martinez",
                            style: GoogleFonts.encodeSans(
                                textStyle: const TextStyle(
                                    fontSize: 24, fontWeight: FontWeight.bold)),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            "Mumbai",
                            style: GoogleFonts.encodeSans(
                                textStyle: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xffBBC3CE))),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 15),
                ListTile(
                  leading: CircleAvatar(
                    radius: 20,
                    child: Icon(Icons.wallet, color: ColorConstants.Button),
                  ),
                  title: Text(
                    "Wallet",
                    style: GoogleFonts.encodeSans(
                      textStyle: const TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: 16,
                          color: Color(0xff070821)),
                    ),
                  ),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 20),
                ),
                InkWell(
                  onTap: () {
                    Get.to(() =>  MyProfile());
                  },
                  child: ListTile(
                    leading: CircleAvatar(
                        radius: 20, child: Image.asset("assets/Icon/pet.png")),
                    title: Text(
                      "My Profile",
                      style: GoogleFonts.encodeSans(
                        textStyle: const TextStyle(
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            color: Color(0xff070821)),
                      ),
                    ),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 20),
                  ),
                ),
                InkWell(
                  onTap: () {
                    Get.to(() =>  Mypets());
                  },
                  child: ListTile(
                    leading: CircleAvatar(
                        radius: 20, child: Image.asset("assets/Icon/help.png")),
                    title: Text(
                      "My Pets",
                      style: GoogleFonts.encodeSans(
                        textStyle: const TextStyle(
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            color: Color(0xff070821)),
                      ),
                    ),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 20),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    Get.to(() =>  MyFavourite());
                  },
                  child: ListTile(
                    leading: CircleAvatar(
                        radius: 20, child: Image.asset("assets/Icon/heart.png")),
                    title: Text(
                      "My favourites",
                      style: GoogleFonts.encodeSans(
                        textStyle: const TextStyle(
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            color: Color(0xff070821)),
                      ),
                    ),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 20),
                  ),
                ),
                ListTile(
                  leading: CircleAvatar(
                      radius: 20, child: Image.asset("assets/Icon/announcement.png")),
                  title: Text(
                    "Invite friends",
                    style: GoogleFonts.encodeSans(
                      textStyle: const TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: 16,
                          color: Color(0xff070821)),
                    ),
                  ),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 20),
                ),
                InkWell(
                  onTap: () {
                    Get.to(() =>  HelpPage());
                  },
                  child: ListTile(
                    leading: CircleAvatar(
                        radius: 20, child: Image.asset("assets/Icon/question.png")),
                    title: Text(
                      "Help",
                      style: GoogleFonts.encodeSans(
                        textStyle: const TextStyle(
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            color: Color(0xff070821)),
                      ),
                    ),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 20),
                  ),
                ),
                InkWell(
                  onTap: () {
                    Get.to(() =>  SettingsPage());
                  },
                  child: ListTile(
                    leading: CircleAvatar(
                        radius: 20, child: Image.asset("assets/Icon/settings gear.png")),
                    title: Text(
                      "Settings",
                      style: GoogleFonts.encodeSans(
                        textStyle: const TextStyle(
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            color: Color(0xff070821)),
                      ),
                    ),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 20),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
