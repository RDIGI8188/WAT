
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
class RescuePetsPage extends StatelessWidget {
  final RescuePetsController controller = Get.put(RescuePetsController());

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(60),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xffED6D4E), Color(0xffF1A852)],
                stops: [0.0, 1.0],
                begin: FractionalOffset.topLeft,
                end: FractionalOffset.bottomRight,
              ),
            ),
            child: AppBar(
              title: Text(
                'Rescue Pets',
                style: TextStyle(color: Colors.white),
              ),
              backgroundColor: Colors.transparent,
              elevation: 0,
            ),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                _buildInputField(controller.idController, 'User ID', TextInputType.number),
                _buildInputField(controller.usernameController, 'Username'),
                _buildInputField(controller.textController, 'Text'),
                _buildInputField(controller.addressController, 'Address'),
                _buildInputField(controller.locationController, 'Location'),
                _buildInputField(controller.detailController, 'Detail'),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: controller.pickImages,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xffED6D4E),
                    minimumSize: Size(double.infinity, 50),
                  ),
                  child: Text('Pick Images (Max 4)'),
                ),
                SizedBox(height: 10),
                Obx(() {
                  return Wrap(
                    spacing: 10,
                    children: controller.imageFiles
                        .map((file) => Image.file(file, width: 100, height: 100))
                        .toList(),
                  );
                }),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: controller.submitData,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xffED6D4E),
                    minimumSize: Size(double.infinity, 50),
                  ),
                  child: Text('Submit Rescue Details'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputField(TextEditingController controller, String label,
      [TextInputType keyboardType = TextInputType.text]) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
        ),
        keyboardType: keyboardType,
      ),
    );
  }
}


class RescuePetsController extends GetxController {
  final TextEditingController idController = TextEditingController();
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController textController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  final TextEditingController detailController = TextEditingController();

  var imageFiles = <File>[].obs; 

  Future<void> pickImages() async {
    final picker = ImagePicker();
    final pickedFiles = await picker.pickMultiImage(imageQuality: 100);

    if (pickedFiles != null && pickedFiles.length <= 2) {
      imageFiles.value = pickedFiles.map((file) => File(file.path)).toList();
    } else {
      Get.snackbar('Error', 'You can only select up to 2 images.',
          backgroundColor: Colors.red, colorText: Colors.white);
    }
  }

  Future<void> submitData() async {
    if (imageFiles.isEmpty) {
      Get.snackbar('Error', 'Please select at least one image.',
          backgroundColor: Colors.red, colorText: Colors.white);
      return;
    }

    var request = http.MultipartRequest(
      'POST',
      Uri.parse('https://app.wingsandtails.in/server/rescue/addRescue.php'),
    );

    request.fields['id'] = idController.text;
    request.fields['username'] = usernameController.text;
    request.fields['text'] = textController.text;
    request.fields['address'] = addressController.text;
    request.fields['location'] = locationController.text;
    request.fields['detail'] = detailController.text;

    for (var imageFile in imageFiles) {
      request.files.add(
        await http.MultipartFile.fromPath('rescue_img[]', imageFile.path),
      );
    }

    try {
      final response = await request.send();
      if (response.statusCode == 200) {
        Get.snackbar('Success', 'Rescue details submitted successfully.',
            backgroundColor: Colors.green, colorText: Colors.white);

        String submittedData = '''
        ID: ${idController.text}
        Username: ${usernameController.text}
        Text: ${textController.text}
        Address: ${addressController.text}
        Location: ${locationController.text}
        Detail: ${detailController.text}
        ''';

        Get.snackbar('Submitted Data', submittedData,
            backgroundColor: Colors.blueAccent, colorText: Colors.white);
      } else {
        Get.snackbar('Error', 'Failed to submit rescue details.',
            backgroundColor: Colors.red, colorText: Colors.white);
      }
    } catch (e) {
      Get.snackbar('Error', 'An error occurred: $e',
          backgroundColor: Colors.red, colorText: Colors.white);
    }
  }
}
