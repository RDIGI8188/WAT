
import 'dart:io';
import 'package:flutter/src/widgets/editable_text.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart'; 
import 'dart:convert';

import 'package:wat/View/Auth/splash.dart';

class ProfileController extends GetxController {
  RxBool isMale = true.obs; 
  Rx<File?> image = Rx<File?>(null); 
  final ImagePicker _picker = ImagePicker();
  RxString mobileNumber = ''.obs; 
  RxString userId = ''.obs; 

  @override
  void onInit() {
    super.onInit();
    loadMobileNumber(); 
    loadUserId();
  }

  Future<void> loadMobileNumber() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    mobileNumber.value = prefs.getString('mobile') ?? ''; 
  }

  Future<void> loadUserId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userId.value = prefs.getString('user_id') ?? ''; 
  }
  Future<void> pickImage(ImageSource source) async {
    final pickedFile = await _picker.pickImage(source: source);
    if (pickedFile != null) {
      image.value = File(pickedFile.path);
    }
  }

  void toggleGender(bool male) {
    isMale.value = male;
  }

  Future<void> updateProfile({
    required String name,
    required String email,
    required String city,
    required String pincode,
    required String address,
    File? profileImage, required TextEditingController mobileNumber,
  }) async {
    final uri = Uri.parse("https://app.wingsandtails.in/server/authUser/updateCustomerProfile.php");

    var request = http.MultipartRequest('POST', uri);
    request.fields['name'] = name;
    request.fields['email'] = email;
    request.fields['mobile'] = mobileNumber.text; 
    request.fields['gender'] = isMale.value ? 'Male' : 'Female';
    request.fields['city'] = city;
    request.fields['pincode'] = pincode;
    request.fields['customer_address'] = address;

    if (profileImage != null) {
      request.files.add(await http.MultipartFile.fromPath(
        'profile_image',
        profileImage.path,
      ));
    }

    try {
      var response = await request.send();
      if (response.statusCode == 200) {
        var responseData = await response.stream.bytesToString();
        var jsonResponse = jsonDecode(responseData);
        print("Profile updated: ${jsonResponse['message']}");
        Get.snackbar("Success", "Profile updated successfully!");
      } else {
        print("Failed to update profile: ${response.statusCode}");
        Get.snackbar("Error", "Failed to update profile.");
      }
    } catch (e) {
      print("Error: $e");
      Get.snackbar("Error", "Something went wrong.");
    }
  }

  Future<void> logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear(); 
    Get.offAll(Splash()); 
  }
}
