

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class RegisterController extends GetxController {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();
  final TextEditingController otpController = TextEditingController();

  Future<void> generateOtp() async {
    String mobileNumber = mobileController.text.trim(); // Trim spaces

    if (mobileNumber.isEmpty || mobileNumber.length < 10) {
      Get.snackbar("Error", "Please enter a valid mobile number (at least 10 digits).");
      return;
    }

    final url = Uri.parse('https://app.wingsandtails.in/server/authUser/mobileOtp.php');
    try {
      final response = await http.post(url, body: {'mobile': mobileNumber});

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = json.decode(response.body);

        if (responseData['success'] ?? false) {
          Get.snackbar("Success", "OTP sent to your mobile number.");
        } else {
          Get.snackbar("Error", responseData['message'] ?? "Failed to send OTP.");
        }
      } else {
        Get.snackbar("Error", "Failed to send OTP. Please try again.");
      }
    } catch (e) {
      Get.snackbar("Error", "An error occurred: $e");
    }
  }

  Future<void> registerUser() async {
    String name = nameController.text.trim(); 
    String email = emailController.text.trim();
    String mobileNumber = mobileController.text.trim();
    String otp = otpController.text.trim();

    if (name.isEmpty) {
      Get.snackbar("Error", "Please enter your name.");
      return;
    }
    if (email.isEmpty || !_isEmailValid(email)) {
      Get.snackbar("Error", "Please enter a valid email.");
      return;
    }
    if (mobileNumber.isEmpty || mobileNumber.length < 10) {
      Get.snackbar("Error", "Please enter a valid mobile number (at least 10 digits).");
      return;
    }
    if (otp.isEmpty) {
      Get.snackbar("Error", "Please enter the OTP.");
      return;
    }

    final url = Uri.parse('https://app.wingsandtails.in/server/authUser/appRegistration.php');
    try {
      final response = await http.post(url, body: {
        'name': name,
        'email': email,
        'mobile_number': mobileNumber,
        'otp': otp,
      });

      if (response.statusCode == 200) {
        String responseBody = response.body;

        if (responseBody.contains('{')) {
          responseBody = responseBody.substring(responseBody.indexOf('{'));
        }

        final Map<String, dynamic> responseData = json.decode(responseBody);

        bool isSuccess = responseData['success'] ?? false;

        if (isSuccess) {
          Get.snackbar("Success", "Registration successful! Welcome, $name!");

          nameController.clear();
          emailController.clear();
          mobileController.clear();
          otpController.clear();
        } else {
          Get.snackbar("Error", responseData['message'] ?? "Unknown error occurred.");
        }
      } else {
        Get.snackbar("Error", "Failed to register. Please try again.");
      }
    } catch (e) {
      Get.snackbar("Error", "An error occurred: $e");
    }
  }

  bool _isEmailValid(String email) {
    final RegExp emailRegExp = RegExp(r'^[^@]+@[^@]+\.[a-zA-Z]{2,}$');
    return emailRegExp.hasMatch(email);
  }
}
