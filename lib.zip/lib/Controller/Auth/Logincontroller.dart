import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import '../../bottombar.dart';

class ApiService {
  static const String baseUrl = 'https://app.wingsandtails.in/server/authUser/appLogin.php';

  String? generatedOtp;

  Future<void> generateOtp(String mobile) async {
    final response = await http.post(
      Uri.parse(baseUrl),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: {
        'action': 'generate',
        'mobile': mobile,
      },
    );

    if (response.statusCode == 200) {
      var jsonResponse = json.decode(response.body);
      print('OTP Generated: ${jsonResponse['message']}');
      print(jsonResponse);
      generatedOtp = jsonResponse['otp'].toString();
      print('Generated OTP: $generatedOtp');
    } else {
      print('Failed to generate OTP');
      throw Exception('Failed to generate OTP');
    }
  }

  Future<Map<String, dynamic>> verifyOtp(String mobile, String otp) async {
    final response = await http.post(
      Uri.parse(baseUrl),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: {
        'action': 'verify',
        'mobile': mobile,
        'otp': otp,
      },
    );

    if (response.statusCode == 200) {
      var jsonResponse = json.decode(response.body);
      print('OTP Verified: ${jsonResponse['message']}');
      print(jsonResponse);
      
      if (jsonResponse['user'] != null) {
        return jsonResponse['user']; 
      } else {
        throw Exception('User data not found');
      }
    } else {
      throw Exception('Failed to verify OTP');
    }
  }
}

class LoginController extends GetxController {
  final phoneNumber = ''.obs;
  final otp = ''.obs;
  final formKey = GlobalKey<FormState>();

  final ApiService apiService = ApiService(); 

  @override
  void onInit() {
    super.onInit();
    checkLoginStatus(); 
  }

  Future<void> checkLoginStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? mobile = prefs.getString('mobile');
    if (mobile != null) {
      Get.offAll(Bottombar()); 
    }
  }

  Future<void> generateAndSendOtp() async {
    if (phoneNumber.value.isNotEmpty) {
      try {
        await apiService.generateOtp(phoneNumber.value); 

        Get.snackbar(
          'OTP Sent',
          'A new OTP has been sent successfully to ${phoneNumber.value}.',
          backgroundColor: Colors.green,
          colorText: Colors.white,
        );
        otp.value = ''; 
      } catch (e) {
        showError('An error occurred while sending OTP: $e');
      }
    } else {
      showError('Please enter a valid phone number.');
    }
  }

Future<void> verifyOtpAndLogin() async {
  if (otp.value.isNotEmpty) {
    try {
      final userDetails = await apiService.verifyOtp(phoneNumber.value, otp.value.trim());
      print('User Details: $userDetails');  

      Get.snackbar('Success', 'Login successful!',
          backgroundColor: Colors.green, colorText: Colors.white);

      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('mobile', userDetails['mobile'] ?? '');
      await prefs.setString('user_id', userDetails['user_id']?.toString() ?? '');
      await prefs.setString('user_name', userDetails['user_name'] ?? '');
      await prefs.setString('user_email', userDetails['user_email'] ?? '');
      await prefs.setString('user_gender', userDetails['user_gender'] ?? '');
      await prefs.setString('user_city', userDetails['user_city'] ?? '');
      await prefs.setString('user_pincode', userDetails['user_pincode'] ?? '');
      await prefs.setString('user_profile_image', userDetails['user_profile_image'] ?? '');
      await prefs.setString('referal_code', userDetails['referal_code'] ?? '');
      await prefs.setString('wallet_amt', userDetails['wallet_amt']?.toString() ?? '');

      print("Navigating to Bottombar");
      Get.offAll(Bottombar()); 
    } catch (e) {
      if (e.toString().toLowerCase().contains('otp has expired')) {
        showError('OTP has expired. Please request a new OTP.');
      } else {
        showError('An error occurred while verifying OTP: $e');
      }
    }
  } else {
    showError('Please enter the OTP.');
  }
}

  void showError(String message) {
    Get.snackbar('Error', message,
        backgroundColor: Colors.red, colorText: Colors.white);
  }

  Future<void> logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear(); 
    Get.offAllNamed('/login'); 
  }
}
